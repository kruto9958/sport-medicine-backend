const jwt = require('jsonwebtoken');

const SECRET = process.env.JWT_SECRET || 'sport-medicine-secret-key-2024';

function authenticate(req, res, next) {
  const header = req.headers.authorization;

  if (!header || !header.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Token ne predostavlen' });
  }

  const token = header.split(' ')[1];

  try {
    const decoded = jwt.verify(token, SECRET);
    req.userId = decoded.id;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Neverny ili prosrochenny token' });
  }
}

module.exports = { authenticate, SECRET };