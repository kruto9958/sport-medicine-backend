const express = require('express');
const cors = require('cors');

require('./db');
require('./data/seed');

const authRoutes = require('./routes/auth');
const taskRoutes = require('./routes/tasks');
const solutionRoutes = require('./routes/solutions');
const leaderboardRoutes = require('./routes/leaderboard');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

app.use('/api/auth', authRoutes);
app.use('/api/tasks', taskRoutes);
app.use('/api/solutions', solutionRoutes);
app.use('/api/leaderboard', leaderboardRoutes);

app.get('/', (req, res) => {
  res.json({
    message: 'Sportivnoe vrachevanie - API rabotaet',
    endpoints: {
      'POST /api/auth/register': 'Registratsiya',
      'POST /api/auth/login': 'Vkhod',
      'GET  /api/auth/me': 'Moy profil (nuzhen token)',
      'GET  /api/tasks': 'Spisok zadach (nuzhen token)',
      'GET  /api/tasks/:id': 'Zadacha po ID (nuzhen token)',
      'POST /api/solutions/:taskId/solve': 'Otpravit reshenie (nuzhen token)',
      'GET  /api/solutions/my': 'Moi resheniya (nuzhen token)',
      'GET  /api/leaderboard': 'Tablitsa liderov'
    }
  });
});

app.listen(PORT, () => {
  console.log('Server zapushchen: http://localhost:' + PORT);
});