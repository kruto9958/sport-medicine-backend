const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../db');
const { authenticate, SECRET } = require('../middleware/auth');

const router = express.Router();

router.post('/register', (req, res) => {
  const { username, email, password } = req.body;

  if (!username || !email || !password) {
    return res.status(400).json({ error: 'Vse polya obyazatelny' });
  }

  if (password.length < 6) {
    return res.status(400).json({ error: 'Parol minimum 6 simvolov' });
  }

  const existing = db.prepare('SELECT id FROM users WHERE email = ? OR username = ?').get(email, username);
  if (existing) {
    return res.status(409).json({ error: 'Polzovatel uzhe sushchestvuet' });
  }

  const hash = bcrypt.hashSync(password, 10);
  const result = db.prepare('INSERT INTO users (username, email, password) VALUES (?, ?, ?)').run(username, email, hash);

  const token = jwt.sign({ id: result.lastInsertRowid }, SECRET, { expiresIn: '7d' });

  res.status(201).json({
    message: 'Registratsiya uspeshna',
    token,
    user: { id: result.lastInsertRowid, username, email, score: 0 }
  });
});

router.post('/login', (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'Email i parol obyazatelny' });
  }

  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user) {
    return res.status(401).json({ error: 'Neverny email ili parol' });
  }

  if (!bcrypt.compareSync(password, user.password)) {
    return res.status(401).json({ error: 'Neverny email ili parol' });
  }

  const token = jwt.sign({ id: user.id }, SECRET, { expiresIn: '7d' });

  res.json({
    message: 'Vkhod uspeshen',
    token,
    user: { id: user.id, username: user.username, email: user.email, score: user.score }
  });
});

router.get('/me', authenticate, (req, res) => {
  const user = db.prepare('SELECT id, username, email, score, solved_count, created_at FROM users WHERE id = ?').get(req.userId);

  if (!user) {
    return res.status(404).json({ error: 'Polzovatel ne nayden' });
  }

  res.json(user);
});

module.exports = router;