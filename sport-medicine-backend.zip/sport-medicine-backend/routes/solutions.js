const express = require('express');
const db = require('../db');
const { authenticate } = require('../middleware/auth');

const router = express.Router();

router.post('/:taskId/solve', authenticate, (req, res) => {
  const { taskId } = req.params;
  const { answer } = req.body;

  if (!answer) {
    return res.status(400).json({ error: 'Otvet ne mozhet byt pustym' });
  }

  const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(taskId);
  if (!task) {
    return res.status(404).json({ error: 'Zadacha ne naydena' });
  }

  const alreadySolved = db.prepare(
    'SELECT id FROM solutions WHERE user_id = ? AND task_id = ? AND is_correct = 1'
  ).get(req.userId, taskId);

  if (alreadySolved) {
    return res.status(400).json({ error: 'Vy uzhe pravilno reshili etu zadachu' });
  }

  const correctWords = task.correct_answer.toLowerCase().split(/[\s,.\-\/]+/).filter(w => w.length > 3);
  const userWords = answer.toLowerCase();
  const matchCount = correctWords.filter(w => userWords.includes(w)).length;
  const isCorrect = matchCount >= Math.ceil(correctWords.length * 0.4);

  db.prepare('INSERT INTO solutions (user_id, task_id, answer, is_correct) VALUES (?, ?, ?, ?)')
    .run(req.userId, taskId, answer, isCorrect ? 1 : 0);

  if (isCorrect) {
    db.prepare('UPDATE users SET score = score + ?, solved_count = solved_count + 1 WHERE id = ?')
      .run(task.points, req.userId);
  }

  const user = db.prepare('SELECT score, solved_count FROM users WHERE id = ?').get(req.userId);

  res.json({
    is_correct: isCorrect,
    message: isCorrect
      ? 'Pravilno! +' + task.points + ' ochkov'
      : 'Neverno. Poprobuyte eshche raz.',
    correct_answer: isCorrect ? task.correct_answer : undefined,
    score: user.score,
    solved_count: user.solved_count
  });
});

router.get('/my', authenticate, (req, res) => {
  const solutions = db.prepare(`
    SELECT s.id, s.task_id, t.title, s.is_correct, s.submitted_at
    FROM solutions s
    JOIN tasks t ON s.task_id = t.id
    WHERE s.user_id = ?
    ORDER BY s.submitted_at DESC
  `).all(req.userId);

  res.json(solutions);
});

module.exports = router;