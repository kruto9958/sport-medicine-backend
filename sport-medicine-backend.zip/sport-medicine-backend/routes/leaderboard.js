const express = require('express');
const db = require('../db');

const router = express.Router();

router.get('/', (req, res) => {
  const limit = parseInt(req.query.limit) || 20;

  const leaders = db.prepare(`
    SELECT id, username, score, solved_count, created_at
    FROM users
    ORDER BY score DESC, solved_count DESC
    LIMIT ?
  `).all(limit);

  res.json(leaders);
});

module.exports = router;