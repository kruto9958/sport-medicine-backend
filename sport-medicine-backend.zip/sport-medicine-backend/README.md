# Спортивное врачевание - Backend
## Структура проекта
sport-medicine-backend/
server.js -запуск сервера
db.js - подключение и создание базы данных SQLite
database.sqlite - файл базы данных (создаётся автоматически)
package.json - зависимости проекта
routes/
auth.js - регистрация, вход, профиль пользователя
tasks.js - список задач и задача по ID
solutions.js - отправка решений и история решений
leaderboard.js - таблица лидеров
middleware/
auth.js - проверка JWT токена
data/
seed.js - начальные медицинские задачи 

## Запуск (для первого раза)
Открыть терминал в VS Code (Ctrl + ~) и выполнить по порядку:
  cd sport-medicine-backend
  npm install
  node server.js
после:  http://localhost:3000 (остановка Ctrl + C в терминале)